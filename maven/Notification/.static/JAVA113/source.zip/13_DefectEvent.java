package com.codescroll.notification.constants;

public enum DefectEvent {
  STATUS_CHANGED,
  SELECTED,
  SUPPRESSED,
  RESOLVED,
  REOPEN,
  ASSIGNED,
  COMMENTED
}
