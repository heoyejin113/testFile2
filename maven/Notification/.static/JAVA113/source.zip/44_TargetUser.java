package com.codescroll.notification.constants;

public enum TargetUser {
  PROJECT_ADMINISTRATOR,
  USERS_WHO_STAR_PROJECT,
  DEFECT_ASSIGNEE
}
