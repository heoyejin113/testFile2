package com.codescroll.notification.constants;

public enum MAIL_SERVER_PROTOCOL {
  smtp,
  secure_smtp
}
