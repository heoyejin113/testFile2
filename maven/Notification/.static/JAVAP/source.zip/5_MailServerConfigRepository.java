package com.codescroll.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MailServerConfigRepository extends JpaRepository<MailServerConfig, String> {
}
