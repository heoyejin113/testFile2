package com.codescroll.notification.service.message;

public interface IMessageGenerator {
  String generateHtml();
}
