package com.codescroll.notification.exception;

public class MailServerException extends Exception {
  public MailServerException(String message, Throwable cause) {
    super(message, cause);
  }
}
