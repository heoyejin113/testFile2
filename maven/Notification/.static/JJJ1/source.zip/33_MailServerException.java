package com.codescroll.notification.exception;

public class MailServerException extends Exception {//ㄴㄴㄴ
  public MailServerException(String message, Throwable cause) {
    super(message, cause);
  }
}
