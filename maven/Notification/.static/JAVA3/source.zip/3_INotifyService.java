package com.codescroll.notification.service.notify;

public interface INotifyService {
}
