package hello;

public class Greeter {
  public String sayHello() {
    return "Hello world!";
  }
}